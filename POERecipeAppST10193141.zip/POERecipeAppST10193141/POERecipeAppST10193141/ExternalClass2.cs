﻿using global::POERecipeAppST10193141;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POERecipeAppST10193141

{
    internal class ExternalClass2
    {

        public void getDetails()
        {
            ExternalClass1 EXT1 = new ExternalClass1();

            int NI_Loop = 0;
            Console.WriteLine("Number of ingredients");
            NI_Loop = Convert.ToInt32(Console.ReadLine());

            //  for (int p = 0; p < NI_Loop; p++)
            // {



            String[] N = new String[NI_Loop];
            Program.IngredientName = N;
            int[] Q = new int[NI_Loop];
            Program.Quantity = Q;
            int[] UNM = new int[NI_Loop];
            Program.UnitofMeasurement = UNM;
            int[] FB = new int[NI_Loop];
            Program.FactorBy = FB;
            String[] SbSD = new String[NI_Loop];
            Program.StepbyStepdescription = SbSD;

            int Count = 0;
            for (int i = 0; i < NI_Loop; i++)
            {
                Count++;
                Count = i;

                Console.WriteLine("Name of the ingredient :");
                N[i] = Console.ReadLine();
                Console.WriteLine("Quantity of Ingredient :");
                Q[i] = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Unit of measurement of Ingredient :");
                UNM[i] = Convert.ToInt32(Console.ReadLine());


                Console.WriteLine("Name  of Ingredient : " + N[i]);
                Console.WriteLine("Quantity of Ingredient : " + Q[i]);
                Console.WriteLine("Unit of measurement of Ingredient : " + UNM[i]);







                Console.WriteLine("The recipe Scaled by :\r\n"
                                                        + "0.5(Half) .1\r\n"
                                                        + "2 (Double).2\r\n"
                                                        + "3 (Triple).3");
                FB[Count] = Convert.ToInt32(Console.ReadLine());

                if (FB[Count] == 1)
                {
                    double ans1 = 0;
                    double ans2 = 0;
                    ans1 = Q[Count] * 0.5;
                    ans2 = UNM[Count] * 0.5;
                    Console.WriteLine("Ingredients Scaled by :0.5(Half))\r\n" +
                                      "New Factor : Quantity :" + ans1
                                                 + "\r\nUnit of measurement :" + ans2);
                }
                else if (FB[Count] == 2)
                {
                    double ans1 = 0;
                    double ans2 = 0;
                    ans1 = Q[Count] * 2;
                    ans2 = UNM[Count] * 2;
                    Console.WriteLine("Ingredients Scaled by :2 (Double))\r\n" +
                                      "New Factor : Quantity :" + ans1
                                                 + "\r\nUnit of measurement :" + ans2);
                }
                else if (FB[Count] == 3)
                {
                    double ans1 = 0;
                    double ans2 = 0;
                    ans1 = Q[Count] * 3;
                    ans2 = UNM[Count] * 3;
                    Console.WriteLine("Ingredients Scaled by :3 (Triple))\r\n" +
                                      "New Factor : Quantity :" + ans1
                                                 + "\r\nUnit of measurement :" + ans2);
                }

            }
            Console.WriteLine("Enter Recipe description use a comma (,) separate the steps");
            SbSD = Console.ReadLine().Split(new char[] { ',' });
            for (int i = 0; i < SbSD.Length; i++)
            {
                Console.WriteLine(SbSD[i]);
            }

            Console.WriteLine("Press 1-Go back to menue \r\n" +
                              "2-Close app");
            int Option = 0;
            Option = Convert.ToInt32(Console.ReadLine());
            if (Option == 1)
            {
                EXT1.Menue();
            }
            else if (Option == 2)
            {
                System.Environment.Exit(0);
            }

        }
        public void Print()
        {
            Program P = new Program();
            ExternalClass1 EXT1 = new ExternalClass1();
            ExternalClass2 EXT2 = new ExternalClass2();

            String[] IN = Program.IngredientName;
            int[] Q = Program.Quantity;
            int[] UNM = Program.UnitofMeasurement;
            int[] FB = Program.FactorBy;
            String[] SbSd = Program.StepbyStepdescription;
            for (int i = 0; i < IN.Length; i++)
            {

                Console.WriteLine("Ingredient Name :" + IN[i]);
            }
            for (int i = 0; i < Q.Length; i++)
            {
                Console.WriteLine("Ingredient Quantity :" + Q[i]);
            }
            for (int i = 0; i < UNM.Length; i++)
            {

                Console.WriteLine("Ingredient Unit of Measurement :" + UNM[i]);
            }
            foreach (String i in SbSd)

            {
                Console.WriteLine("Ingredient Step by Step Description :" + i);
            }

            Console.WriteLine("Press 1-Go back to menue \r\n" +
                            "2-Close app");
            int Option = 0;
            Option = Convert.ToInt32(Console.ReadLine());
            if (Option == 1)
            {
                EXT1.Menue();
            }
            else if (Option == 2)
            {
                System.Environment.Exit(0);
            }




        }

    }

}





    