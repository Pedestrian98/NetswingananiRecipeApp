﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace POERecipeAppST10193141
{
    internal class ExternalClass1
    {
        public void Menue()
        {
            ExternalClass2 EXT2 = new ExternalClass2();
            ExternalClass3 EXT3 = new ExternalClass3();
            Console.WriteLine("Press the following number keys for the option you want");
            Console.WriteLine("1- Create a new recipe");
            Console.WriteLine("2- Reset your recipe Quantities to original values");
            Console.WriteLine("3- Print you recipe");
            Console.WriteLine("4- Exit ");

            int Option = 0;
            Option = Convert.ToInt32(Console.ReadLine());
            if (Option == 1)
            {
                EXT2.getDetails();

            }
            else if (Option == 2)
            {
                EXT3.ResetDetails();
            }
            else if (Option == 3)
            {
                EXT2.Print();
            }
            else if (Option == 4)
            {
                System.Environment.Exit(0);
            }
        }
    }
}