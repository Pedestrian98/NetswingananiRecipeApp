﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Text;
using System.Threading.Tasks;

namespace POERecipeAppST10193141
{
    internal class Program
    {
        public static String[] IngredientName;
        public static int[] Quantity;
        public static int[] UnitofMeasurement;
        public static int[] FactorBy;
        public static String[] StepbyStepdescription;
        static void Main(string[] args)
        {
            ExternalClass1 EXT1 = new ExternalClass1();
            EXT1.Menue();
        }
    }
}

