﻿using global::POERecipeAppST10193141;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POERecipeAppST10193141
{
    internal class ExternalClass3
    {

        public void ResetDetails()
        {
            Program P = new Program();
            ExternalClass1 EXT1 = new ExternalClass1();
            ExternalClass2 EXT2 = new ExternalClass2();
            int[] NewQuantity = new int[1];
            String[] IN = Program.IngredientName;
            int[] Q = Program.Quantity;
            int[] UNM = Program.UnitofMeasurement;
            int[] FB = Program.FactorBy;
            String[] SbSd = Program.StepbyStepdescription;

            Console.WriteLine("Press 1 to Clear Recipe \r\n" +
                                    "2 to cancel and go back to menue");
            int Option = 0;
            Option = Convert.ToInt32(Console.ReadLine());

            if (Option == 1)
            {



                Console.WriteLine("Recipe reset successfull");
                Array.Clear(IN, 0, IN.Length);
                Array.Clear(Q, 0, Q.Length);
                Array.Clear(UNM, 0, UNM.Length);
                Array.Clear(SbSd, 0, SbSd.Length);


                foreach (String i in IN)
                {
                    Console.WriteLine("Ingredient Name :" + i);
                }
                foreach (int i in Q)
                {
                    Console.WriteLine("Quantity :" + i);
                }
                foreach (int i in UNM)
                {
                    Console.WriteLine("Unit of Measurement :" + i);
                }
                foreach (String i in SbSd)
                {
                    Console.WriteLine("Steps by Step description :" + i);
                }
                //new recipe
                Console.WriteLine("1- Create a new Recipe \r\n" +
                                  "2-Back to Menue ");
                int OptioN = 0;
                OptioN = Convert.ToInt32(Console.ReadLine());
                if (OptioN == 1)
                {
                    EXT2.getDetails();
                }
                else if (OptioN == 2)
                {
                    EXT1.Menue();
                }

                //incase this does not work make redundant code and just print blank cw and creaye a new array
            }
            else if (Option == 2)
            {
                EXT1.Menue();

            }

            Console.ReadLine();
        }

    }
}










